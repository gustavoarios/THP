package practica;

import java.util.Scanner;

public class Ropa {

	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		int dni = 1;
		String producto = "";

		while (dni != 0) {

			do {

				System.out.println("Ingrese su DNI: ");
				dni = Integer.parseInt(input.nextLine());

			} while (dni < 0);

			if (dni > 0) {

				do {
					
					System.out.println("Ingrese código de producto (REMERA, PANTALON o SWEATER). Para finalizar venta escriba FIN");
					producto = input.nextLine().toUpperCase();
					
					System.out.println("lokita");

				} while (!producto.equals("fin") && !producto.equals("remera") && !producto.equals("pantalon") && !producto.equals("sweater"));

				if (!producto.equals("fin")) {
					
					System.out.println("hacemos la suma de los productos.");

					System.out.println("El total de la venta es: $45.000,00");

				} else if (producto.equals("fin")) {
					System.out.println("le tiro el total de la venta del tipo y pregunto por otro dni.");
				}

			} else {

				System.out.println("Han finalizado las ventas del día.");
				System.out.println();

			}

		}
		input.close();

	}

}
