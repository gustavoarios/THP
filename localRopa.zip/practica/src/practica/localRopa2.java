package practica;

import java.util.Scanner;

public class localRopa2 {

	private static final int REMERA = 800;
	private static final int PANTALON = 2500;
	private static final int SWEATER = 1200;

	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		int dni;
		String codProd = "";
		int subtotal = 0;
		int cant = 0;
		char color = ' ';

		do {

			System.out.println("Ingrese su DNI, para finalizar el día ingrese 0: ");
			dni = Integer.parseInt(input.nextLine());

		} while (dni < 0);

		if (dni != 0) {

			codProd = "";

			while (codProd != "FIN") {

				do {

					System.out.println(
							"Ingrese código de producto (REMERA, PANTALON o SWEATER). Para finalizar venta escriba FIN: ");
					codProd = input.nextLine().toUpperCase();

				} while (!codProd.equals("REMERA") && !codProd.equals("PANTALON") && !codProd.equals("SWEATER")
						&& !codProd.equals("FIN"));

				if (codProd.equals("fin")) {
					subtotal = 12;
					System.out.println(subtotal);
				} else {
					System.out.println("Aca hacemos la cuenta en teoría.");
				}

			}

		} else {

			System.out.println("Aca cayó siendo igual a 0");

		}
		input.close();

	}

};
